package com.example.joanna.musicplayer1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/**
 * Created by Joanna on 20.03.2018.
 */

public class ActiveSong extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.active_song);
            initializeUI();

        }


        private void initializeUI() {
            Button mPlayButton = (Button) findViewById(R.id.button_play);
            Button mPauseButton = (Button) findViewById(R.id.button_pause);
            Button mResetButton = (Button) findViewById(R.id.button_reset);

            mPlayButton.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Toast.makeText(getApplicationContext(), "play" , Toast.LENGTH_SHORT).show();
                        }
                    });

            mPauseButton.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Toast.makeText(getApplicationContext(), "pause" , Toast.LENGTH_SHORT).show();
                        }
                    });

            mResetButton.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Toast.makeText(getApplicationContext(), "reset" , Toast.LENGTH_SHORT).show();
                        }
                    });
        }





                }


