package com.example.joanna.musicplayer1;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;


import java.util.ArrayList;
/**
 * Created by Joanna on 19.03.2018.
 */

public class RockMusic extends Fragment {


    public RockMusic() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);
        getSupportFragmentManager().addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
            @Override
            public void onBackStackChanged() {
                int stackHeight = getSupportFragmentManager().getBackStackEntryCount();
                if (stackHeight > 0) { // if we have something on the stack (doesn't include the current shown fragment)
                    getSupportActionBar().setHomeButtonEnabled(true);
                    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                } else {
                    getSupportActionBar().setDisplayHomeAsUpEnabled(false);
                    getSupportActionBar().setHomeButtonEnabled(false);
                }
            }

        });

        // Create a list of words
        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word("Thunder", "Imagine Dragons", "3:24"));
        words.add(new Word("Whatever It Takes", "Imagine Dragons", "3:40"));
        words.add(new Word("Feel It Still", "Portugal. The Man", "2:51"));
        words.add(new Word("Believer", "Imagine Dragons", "3:37"));
        words.add(new Word("Zombie", "Bad Wolves", "4:36"));
        words.add(new Word("Sit Next To Me", "Foster The People", "4:06"));
        words.add(new Word("No Roots", "Alice Merton", "3:57"));
        words.add(new Word("One Foot", "WALK THE MOON", "4:20"));
        words.add(new Word("Gone Away", "Five Finger Death Punch", "5:03"));
        words.add(new Word("Live In The Moment", "Portugal. The Man", "3:44"));

        // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
        // adapter knows how to create list items for each item in the list.
        WordAdapter adapter = new WordAdapter(getActivity(), words, R.color.list_song);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // word_list.xml layout file.
        ListView listView = (ListView) rootView.findViewById(R.id.list);

        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        listView.setAdapter(adapter);

        // Set a click listener to play the song of choose
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                // Get the {@link Word} object at the given position the user clicked on
                Word word = words.get(position);

                Intent activeSongintent = new Intent(view.getContext(), ActiveSong.class);
                startActivity(activeSongintent);
            }});
        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
            switch (item.getItemId()) {
                case android.R.id.home:
                    getSupportFragmentManager().popBackStack();
                    return true;
        }};

        return rootView;
    }}
